import LoginForm from "../components/auth/LoginForm.jsx";

const Login = () => {
  return <LoginForm />;
};

export default Login;

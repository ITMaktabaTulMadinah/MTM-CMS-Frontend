import RegisterForm from "../components/auth/RegisterForm.jsx";

const Register = () => {
  return <RegisterForm />;
};

export default Register;

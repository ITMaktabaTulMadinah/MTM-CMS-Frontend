import ComplaintForm from "../components/complaints/ComplaintForm.jsx";

const ComplaintFormPage = () => {
  return <ComplaintForm />;
};

export default ComplaintFormPage;
